Hi Team,

Thanks for giving me this opportunity.


"Brizpal_CowenTest" is the Published Folder.
"SecuritiesApp_BrizpalTest" is the Solution Folder.
Securities.csv sits in C Drive

Things I could have worked on better.

1) Error Catching using Try Catch
2) Creating API/ Service for Reading CSV or Generating FX
3) In real world I will put grid in a pratial view.
4) Comments.
5) Usage of appsettings.json to define constants like USD, file path.
6) Upload on GIT.



Thanks,
Brizpal