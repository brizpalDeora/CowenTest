﻿using CsvHelper.Configuration;
using SecuritiesApp_BrizpalTest.Models;

namespace SecuritiesApp_BrizpalTest.Mapper
{
    public class SecuiritesMap : ClassMap<SecurityModel>
    {
        public SecuiritesMap()
        {
            Map(m => m.LastTradeDate).Name("Last Trade Date");
            Map(m => m.SecurityName).Name("Security");
            Map(m => m.Currency).Name("Currency");
            Map(m => m.Price).Name("Price");
        }
    }
}
