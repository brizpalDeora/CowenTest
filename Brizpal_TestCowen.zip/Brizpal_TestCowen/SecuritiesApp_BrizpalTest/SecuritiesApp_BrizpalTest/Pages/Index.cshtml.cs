﻿using CsvHelper;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SecuritiesApp_BrizpalTest.Models;
using SecuritiesApp_BrizpalTest.Mapper;

namespace SecuritiesApp_BrizpalTest.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public List<SecurityModel> securityModelslist;
        private decimal fxRate;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            securityModelslist = buildSecurityModelsList();

        }

        private List<SecurityModel> buildSecurityModelsList()
        {

            List<SecurityModel> securityModels = new List<SecurityModel>();
            securityModels = readCSV("C:\\Securities.CSV");

            securityModelslist = new List<SecurityModel>();
            foreach (var security in securityModels)
            {
                securityModelslist.Add(new SecurityModel
                {
                    LastTradeDate = security.LastTradeDate,
                    SecurityName = security.SecurityName,
                    Currency = security.Currency,
                    Price = security.Price,
                    FxRate = getFxRate(security.Currency),
                    USDPrice = security.Price * fxRate
                });
            }
            return securityModelslist;
        }

        private List<SecurityModel> readCSV(string filePath)
        {

            using (var reader = new StreamReader(filePath))
            using (var csvFile = new CsvReader(reader, System.Globalization.CultureInfo.CreateSpecificCulture("en-GB")))
            {
                var map = new SecuiritesMap();
                csvFile.Context.RegisterClassMap(map);
                return csvFile.GetRecords<SecurityModel>().ToList();
            }
        }

        private decimal getFxRate(string currency)
        {
            if (currency == "USD")
            {
                fxRate = 1;
                return fxRate;
            }
            else
            {
                Random randomFx = new Random();
                fxRate = (decimal)randomFx.NextDouble();
                return fxRate;
            }
        }

    }
}