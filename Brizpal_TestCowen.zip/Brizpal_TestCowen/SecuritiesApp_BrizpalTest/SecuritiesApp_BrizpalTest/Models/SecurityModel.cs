﻿using System.ComponentModel;

namespace SecuritiesApp_BrizpalTest.Models
{
    public class SecurityModel
    {
        [DisplayName("Last Trade Date")]
        public string LastTradeDate { get; set; }

        [DisplayName("Security")]
        public string SecurityName { get; set; }

        [DisplayName("Currency")]
        public string Currency { get; set; }

        [DisplayName("Price")]
        public decimal Price { get; set; }

        [DisplayName("FX Rate")]
        public decimal FxRate { get; set; }

        [DisplayName("USD Price")]
        public decimal USDPrice { get; set; }
    }
}
